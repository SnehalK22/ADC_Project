package com.SnehalADCApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnehalADCApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnehalADCApplication.class, args);
		System.err.println("DCS is Runnnnnnnnning.............");
	}

}
